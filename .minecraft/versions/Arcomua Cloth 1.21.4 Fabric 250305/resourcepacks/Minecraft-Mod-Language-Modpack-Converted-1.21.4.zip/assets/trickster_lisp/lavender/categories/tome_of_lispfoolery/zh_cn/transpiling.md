```json
{
  "title": "转译",
  "icon": "minecraft:redstone"
}
```

转译器工作方式及相关特性的详细介绍。