```json
{
  "title": "灰烬砖块",
  "icon": "supplementaries:ash_bricks",
  "categories": [
    "minecraft:blocks",
    "minecraft:group/building_blocks"
  ],
  "associated_items": [
    "supplementaries:ash_bricks"
  ]
}
```

&spotlight(supplementaries:ash_bricks)
**灰烬砖块**是[灰烬](^supplementaries:ash)的砖块版本。

;;;;;

&title(合成)
<recipe;supplementaries:ash_bricks>

;;;;;

&title(合成材料)
<recipe;supplementaries:ash_brick_slab>
<recipe;supplementaries:ash_brick_stairs>

;;;;;

&title(烧炼材料)
<recipe;supplementaries:ash_brick_wall>


;;;;;

&title(切石材料)
<recipe;supplementaries:stonecutting/ash_brick_slab_from_bricks>
<recipe;supplementaries:stonecutting/ash_brick_stairs_from_bricks>
<recipe;supplementaries:stonecutting/ash_brick_wall_from_bricks>
