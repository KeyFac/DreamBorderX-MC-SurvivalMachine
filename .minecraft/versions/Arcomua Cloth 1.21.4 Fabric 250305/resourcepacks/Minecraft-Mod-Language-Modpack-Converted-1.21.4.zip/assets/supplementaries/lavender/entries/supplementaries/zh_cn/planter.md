```json
{
  "title": "种植盆",
  "icon": "supplementaries:planter",
  "categories": [
    "minecraft:blocks",
    "minecraft:group/functional_blocks"
  ],
  "associated_items": [
    "supplementaries:planter"
  ]
}
```

&spotlight(supplementaries:planter)
**种植盆**中可以种植任意植物；也可种植农作物，无需水相邻，同时能保护其不遭踩踏。

<block;supplementaries:planter>

;;;;;

![种植盆](supplementaries:textures/gui/image/planters.png,fit)

丛林中的种植盆。

;;;;;

&title(合成)
<recipe;supplementaries:planter>

;;;;;

&title(模组兼容)
有兼容农夫乐事（Farmer's Delight）沃土的变种。
