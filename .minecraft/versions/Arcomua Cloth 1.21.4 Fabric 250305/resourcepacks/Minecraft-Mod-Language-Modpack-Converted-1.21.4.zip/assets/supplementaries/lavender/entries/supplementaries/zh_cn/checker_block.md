```json
{
  "title": "棋盘格方块",
  "icon": "supplementaries:checker_block",
  "categories": [
    "minecraft:blocks",
    "minecraft:group/building_blocks"
  ],
  "associated_items": [
    "supplementaries:checker_block"
  ]
}
```

&spotlight(supplementaries:checker_block)
**棋盘格方块**是一种装饰性方块。

;;;;;

&title(合成)
<recipe;supplementaries:checker>

;;;;;

&title(合成材料)
<recipe;supplementaries:checker_slab>
