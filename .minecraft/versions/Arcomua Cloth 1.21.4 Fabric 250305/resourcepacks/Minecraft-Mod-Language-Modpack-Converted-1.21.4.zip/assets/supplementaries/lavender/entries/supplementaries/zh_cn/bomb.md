```json
{
  "title": "炸弹",
  "icon": "supplementaries:bomb",
  "categories": [
    "minecraft:items",
    "minecraft:group/combat"
  ],
  "associated_items": [
    "supplementaries:bomb"
  ]
}
```

&spotlight(supplementaries:bomb)
**炸弹**是消耗式的弹射物，会在着陆处爆炸。它所产生的爆炸只会对生物造成伤害，而不会摧毁方块。高草丛等会被水冲毁的方块会被摧毁。

;;;;;

&title(合成)
<recipe;supplementaries:bomb>
