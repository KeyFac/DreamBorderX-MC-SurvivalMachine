```json
{
  "title": "石瓦楼梯",
  "icon": "supplementaries:stone_tile_stairs",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag/stairs",
    "minecraft:group/building_blocks"
  ],
  "associated_items": [
    "supplementaries:stone_tile_stairs"
  ]
}
```

&spotlight(supplementaries:stone_tile_stairs)
**石瓦楼梯**是[石瓦](^supplementaries:stone_tiles)的[楼梯](^minecraft:tag/stairs)变种。

;;;;;

&title(合成)
<recipe;supplementaries:stone_tile_stairs>
<recipe;supplementaries:stonecutting/stone_tile_stairs_from_bricks>
