```json
{
  "title": "细木堆台阶",
  "icon": "supplementaries:fine_wood_slab",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag/slabs",
    "minecraft:group/building_blocks"
  ],
  "associated_items": [
    "supplementaries:fine_wood_slab"
  ]
}
```

&spotlight(supplementaries:fine_wood_slab)
**细木堆台阶**是[细木堆](^supplementaries:fine_wood)的[台阶](^minecraft:tag/slabs)变种。

;;;;;

&title(合成)
<recipe;supplementaries:fine_wood_slab>
