```json
{
  "title": "亚麻",
  "icon": "supplementaries:flax",
  "categories": [
    "minecraft:items",
    "minecraft:group/ingredients"
  ],
  "associated_items": [
    "supplementaries:flax"
  ]
}
```

&spotlight(supplementaries:flax)
**亚麻**是能长成两格高的植物，由种植[亚麻种子](^supplementaries:flax_seeds)而来。亚麻可以用于合成许多新增方块，如[绳索](^supplementaries:rope)、[麻布袋](^supplementaries:sack)、[饲料堆](^supplementaries:fodder)、[门垫](^supplementaries:doormat)等。

;;;;;

&title(合成材料)
<recipe;supplementaries:rope>
<recipe;supplementaries:sack>

;;;;;

&title(合成材料)
<recipe;supplementaries:fodder>
<recipe;supplementaries:doormat_2>
