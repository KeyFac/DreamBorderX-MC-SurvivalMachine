```json
{
  "title": "下界合金活板门",
  "icon": "supplementaries:netherite_trapdoor",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag/trapdoors",
    "minecraft:group/building_blocks",
    "minecraft:group/redstone_blocks"
  ],
  "associated_items": [
    "supplementaries:netherite_trapdoor"
  ]
}
```

&spotlight(supplementaries:netherite_trapdoor)
**下界合金活板门**是使用下界合金制造的[活板门](^minecraft:tag/trapdoors)，与[保险箱](^supplementaries:safe)一样可以用[钥匙](^supplementaries:key)上锁。只有持有对应钥匙的人才能与上锁的下界合金活板门交互。


默认情况下，所有人都可与下界合金活板门交互，直至第一次上锁。

;;;;;

&title(合成)
<recipe;supplementaries:netherite_trapdoor>
