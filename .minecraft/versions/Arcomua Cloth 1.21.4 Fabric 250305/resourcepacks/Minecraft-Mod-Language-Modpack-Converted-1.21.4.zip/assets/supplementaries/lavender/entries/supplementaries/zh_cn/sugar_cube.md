```json
{
  "title": "糖块",
  "icon": "supplementaries:sugar_cube",
  "categories": [
    "minecraft:blocks",
    "minecraft:group/functional_blocks"
  ],
  "associated_items": [
    "supplementaries:sugar_cube"
  ]
}
```

&spotlight(supplementaries:sugar_cube)
**糖块**是会在雨中和水中溶解为粒子的方块。

<block;supplementaries:sugar_cube>

;;;;;

&title(合成)
<recipe;supplementaries:sugar_cube>
