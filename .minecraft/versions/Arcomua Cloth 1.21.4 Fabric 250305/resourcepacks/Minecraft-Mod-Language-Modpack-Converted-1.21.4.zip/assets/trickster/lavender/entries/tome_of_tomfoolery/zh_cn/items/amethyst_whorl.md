```json
{
  "title": "紫水晶螺坠",
  "icon": "trickster:amethyst_whorl",
  "category": "trickster:items",
  "ordinal": 0
}
```

紫水晶螺坠不外乎是普通的小饰品，但它确实担得起用：它能存储最多256千甘的魔力，且当作吊坠佩戴时还可按照1千梅的恒定速率充能。


和[晶结](^trickster:items/knots)一样，其中的魔力也可供佩戴者的法术使用。

;;;;;

单片紫水晶碎片即可刻出紫水晶螺坠，再加上简单的铜和线配件即可用作吊坠。

<recipe;trickster:amethyst_whorl>