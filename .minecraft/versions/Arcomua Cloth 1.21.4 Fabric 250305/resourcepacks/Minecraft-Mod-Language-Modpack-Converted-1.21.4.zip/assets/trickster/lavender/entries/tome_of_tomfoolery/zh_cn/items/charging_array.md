```json
{
  "title": "充能阵列",
  "icon": "trickster:charging_array",
  "category": "trickster:items",
  "ordinal": 80
}
```

充能阵列是具有九个槽位的普通石板，槽位中可放置[晶结](^trickster:items/knots)。充能阵列可朝任意方向摆放。阵列中的晶结能接受月光的充能，如同直接丢在地上一样。

;;;;;

充能阵列虽然看上去很像[法术组构台](^trickster:items/spell_construct)，但它们无法施放法术。不过，外部法术仍可与其中的晶结交互，相当于放在一般的容器中。

<recipe;trickster:charging_array>