```json
{
  "title": "卷轴架",
  "icon": "trickster:scroll_shelf",
  "category": "trickster:items",
  "ordinal": 70
}
```

卷轴架是存储卷轴的好方式，也能在视觉上直接展示出你的法术藏品。此方块的功能与雕纹书架类似，手持卷轴右击其前方的空槽位，即可将卷轴放入其中，再次点击就可取出。

;;;;;

经过染色的卷轴放到卷轴架中后，会显示为其染料颜色。将十字准星对准卷轴时，其上会显示其名称以便检索。


卷轴架可与漏斗交互。

<recipe;trickster:scroll_shelf>
