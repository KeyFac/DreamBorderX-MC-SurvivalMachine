```json
{
  "title": "物品",
  "icon": "trickster:macro_ring",
  "ordinal": 0
}
```

本分类下的条目介绍了各式物品，任诸位雄心壮志的魔术师和戏法师们挑选。
