```json
{
  "title": "数学戏法",
  "icon": "minecraft:comparator",
  "parent": "trickster:tricks"
}
```

本分类囊括了数学戏法附属添加的所有戏法。


此处介绍的戏法及图案均需与[**计算之谋略**或**计算之修订**](^trickster-math-tricks:math-tricks)协同使用。